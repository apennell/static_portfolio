<?php
/*
Plugin Name: Pure Shortcodes
Plugin URI: http://www.puremellow.com/shortcodes
Description: Pure Shortcodes. Flexible Shortcodes. For more info and shortcode documentation visi <a href="http://www.puremellow.com/shortcodes">PureMellow.com</a>
Author: Pure Mellow
Author URI: http://www.puremellow.com
Version: 1.0.2
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/


require_once( dirname(__FILE__) . "/class/Pure_ML.php" );
require_once( dirname(__FILE__) . "/class/Pure_Shortcodes.php" );
new Pure_Shortcodes();