(function( $ ){
	
	$(document).ready(function() {
		$("#pure-portfolio-content").fitVids();	
	});

})( jQuery );
